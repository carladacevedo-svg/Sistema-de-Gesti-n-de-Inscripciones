-- Script de ayuda para crear el usuario de aplicación del SGI
-- Ejecutar logueada como root (o un usuario con privilegios de administración)

CREATE DATABASE IF NOT EXISTS sgi
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

DROP USER IF EXISTS 'sgi_user'@'localhost';

CREATE USER 'sgi_user'@'localhost' IDENTIFIED BY 'A3c3ds1991@';

GRANT ALL PRIVILEGES ON sgi.* TO 'sgi_user'@'localhost';

FLUSH PRIVILEGES;
