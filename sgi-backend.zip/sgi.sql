
-- SGI DATABASE INITIALIZATION
DROP DATABASE IF EXISTS sgi;
CREATE DATABASE sgi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sgi;

-- USERS
CREATE TABLE usuarios (
  id BIGINT NOT NULL AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('ADMIN','APROBADOR','ASPIRANTE','JEFE') NOT NULL,
  enabled BIT NOT NULL DEFAULT 1,
  PRIMARY KEY(id)
);

-- ASPIRANTES
CREATE TABLE aspirantes (
  id BIGINT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100) NOT NULL,
  dni VARCHAR(20) NOT NULL UNIQUE,
  email VARCHAR(100),
  telefono VARCHAR(30),
  escalafon VARCHAR(50),
  fecha_nacimiento DATE,
  fecha_alta DATE,
  usuario_id BIGINT UNIQUE,
  FOREIGN KEY(usuario_id) REFERENCES usuarios(id),
  PRIMARY KEY(id)
);

-- APROBADORES
CREATE TABLE aprobadores (
  id BIGINT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  email VARCHAR(100),
  escalafon VARCHAR(50),
  usuario_id BIGINT UNIQUE,
  FOREIGN KEY(usuario_id) REFERENCES usuarios(id),
  PRIMARY KEY(id)
);

-- JEFES
CREATE TABLE jefes (
  id BIGINT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  email VARCHAR(100),
  escalafon VARCHAR(50),
  usuario_id BIGINT UNIQUE,
  FOREIGN KEY(usuario_id) REFERENCES usuarios(id),
  PRIMARY KEY(id)
);

-- TRAMITES
CREATE TABLE tramites (
  id BIGINT NOT NULL AUTO_INCREMENT,
  aspirante_id BIGINT,
  dni VARCHAR(20),
  escalafon VARCHAR(50),
  estado VARCHAR(50),
  fecha_ingreso DATE,
  sla_dias INT,
  jefe_id BIGINT,
  aprobador_id BIGINT,
  PRIMARY KEY(id),
  FOREIGN KEY(aspirante_id) REFERENCES aspirantes(id),
  FOREIGN KEY(jefe_id) REFERENCES jefes(id),
  FOREIGN KEY(aprobador_id) REFERENCES aprobadores(id)
);

-- TIMELINE
CREATE TABLE timeline (
  id BIGINT NOT NULL AUTO_INCREMENT,
  tramite_id BIGINT,
  etapa VARCHAR(100),
  fecha DATE,
  PRIMARY KEY(id),
  FOREIGN KEY(tramite_id) REFERENCES tramites(id)
);

-- SAMPLE USERS
INSERT INTO usuarios (username,password,role,enabled) VALUES
('admin', '$2a$10$KM/uwhTeb3l4ygaTyQhk0uFj3QsLBNOkIMqd.2RF.DejIPEZnOt7m', 'ADMIN', 1),
('jefe1', '$2a$10$KM/uwhTeb3l4ygaTyQhk0uFj3QsLBNOkIMqd.2RF.DejIPEZnOt7m', 'JEFE', 1),
('aprobador1', '$2a$10$KM/uwhTeb3l4ygaTyQhk0uFj3QsLBNOkIMqd.2RF.DejIPEZnOt7m', 'APROBADOR', 1),
('aspirante1', '$2a$10$KM/uwhTeb3l4ygaTyQhk0uFj3QsLBNOkIMqd.2RF.DejIPEZnOt7m', 'ASPIRANTE', 1);

-- SAMPLE PROFILE DATA
INSERT INTO jefes (nombre,email,escalafon,usuario_id) VALUES
('Jefe Principal','jefe1@pfa.gob.ar','SEG',2);

INSERT INTO aprobadores (nombre,email,escalafon,usuario_id) VALUES
('Aprobador Uno','aprobador1@pfa.gob.ar','SEG',3);

INSERT INTO aspirantes (nombre,apellido,dni,email,telefono,escalafon,fecha_nacimiento,fecha_alta,usuario_id) VALUES
('Carlos','Pérez','12345678','carloasp@pfa.gob.ar','1133445566','SEG','1990-01-01','2025-01-01',4),
('Ana','López','22345678','anaasp@pfa.gob.ar','1166778899','COM','1992-05-05','2025-02-01',NULL),
('Luis','Martínez','32345678','luisasp@pfa.gob.ar','1122334455','BOM','1995-09-09','2025-02-10',NULL),
('María','Gómez','42345678','mariasp@pfa.gob.ar','1199887766','SEG','1998-12-12','2025-03-01',NULL),
('Pedro','Sosa','52345678','pedroasp@pfa.gob.ar','1177553311','COM','1991-07-07','2025-03-10',NULL);

-- SAMPLE TRAMITES
INSERT INTO tramites (aspirante_id,dni,escalafon,estado,fecha_ingreso,sla_dias,jefe_id,aprobador_id) VALUES
(1,'12345678','SEG','Ingreso de datos','2025-11-22',5,1,1),
(2,'22345678','COM','Validación documental','2025-11-20',3,1,1),
(3,'32345678','BOM','Aprobación final','2025-11-19',2,1,1);

-- SAMPLE TIMELINE
INSERT INTO timeline (tramite_id,etapa,fecha) VALUES
(1,'Ingreso de datos','2025-11-22'),
(1,'Validación documental','2025-11-23'),
(2,'Ingreso de datos','2025-11-20'),
(2,'Validación documental','2025-11-21'),
(3,'Ingreso de datos','2025-11-19'),
(3,'Aprobación final','2025-11-20');
