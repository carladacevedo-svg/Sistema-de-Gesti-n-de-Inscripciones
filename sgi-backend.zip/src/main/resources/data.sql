-- EJEMPLOS de usuarios APROBADOR y JEFE para probar login.
-- Las contraseñas deben ser BCRYPT, esto es solo un placeholder.
-- Podés borrar este archivo si preferís cargar todo desde tu sistema.

-- INSERT INTO usuarios (id, username, password, role, enabled)
-- VALUES (1, 'aprobador1', '{bcrypt}$2a$10$xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', 'APROBADOR', true);
