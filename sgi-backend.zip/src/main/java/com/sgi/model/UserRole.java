package com.sgi.model;

public enum UserRole {
    ASPIRANTE,
    APROBADOR,
    JEFE,
    ADMIN
}
