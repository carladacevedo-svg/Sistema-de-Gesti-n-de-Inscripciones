package com.sgi.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "aspirantes")
public class Aspirante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(nullable = false, length = 100)
    private String apellido;

    @Column(nullable = false, length = 20, unique = true)
    private String dni;

    @Column(name = "numero_tramite_dni", length = 30)
    private String numeroTramiteDni;

    @Column(name = "fecha_nacimiento")
    private LocalDate fechaNacimiento;

    @Column(length = 100)
    private String email;

    @Column(length = 30)
    private String telefono;

    @Column(name = "escalafon", length = 50)
    private String escalafon;

    @Column(name = "cargo_postulado", length = 100)
    private String cargoPostulado;

    @Column(name = "fecha_alta")
    private LocalDate fechaAlta = LocalDate.now();

    @OneToOne
    @JoinColumn(name = "usuario_id")
    private AppUser usuario;

    public Aspirante() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNumeroTramiteDni() {
        return numeroTramiteDni;
    }

    public void setNumeroTramiteDni(String numeroTramiteDni) {
        this.numeroTramiteDni = numeroTramiteDni;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEscalafon() {
        return escalafon;
    }

    public void setEscalafon(String escalafon) {
        this.escalafon = escalafon;
    }

    public String getCargoPostulado() {
        return cargoPostulado;
    }

    public void setCargoPostulado(String cargoPostulado) {
        this.cargoPostulado = cargoPostulado;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public AppUser getUsuario() {
        return usuario;
    }

    public void setUsuario(AppUser usuario) {
        this.usuario = usuario;
    }
}
