package com.sgi.controller;

import com.sgi.dto.CreateAspiranteRequest;
import com.sgi.model.Aspirante;
import com.sgi.service.AspiranteService;
import com.sgi.service.EmailService;
import com.sgi.service.PdfService;
import jakarta.validation.Valid;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/aspirantes")
@CrossOrigin(origins = "*")
public class AspiranteController {

    private final AspiranteService aspiranteService;
    private final PdfService pdfService;
    private final EmailService emailService;

    public AspiranteController(AspiranteService aspiranteService,
                               PdfService pdfService,
                               EmailService emailService) {
        this.aspiranteService = aspiranteService;
        this.pdfService = pdfService;
        this.emailService = emailService;
    }

    @PostMapping("/preinscripcion")
    public ResponseEntity<ByteArrayResource> preinscripcion(@Valid @RequestBody CreateAspiranteRequest request) {
        Aspirante aspirante = aspiranteService.crearAspirante(request);

        byte[] pdfBytes = pdfService.generarPreinscripcionPdf(aspirante);

        if (aspirante.getEmail() != null && !aspirante.getEmail().isEmpty()) {
            emailService.enviarPreinscripcion(aspirante.getEmail(), pdfBytes);
        }

        ByteArrayResource resource = new ByteArrayResource(pdfBytes);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=preinscripcion.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .contentLength(pdfBytes.length)
                .body(resource);
    }

    @GetMapping("/me")
    @PreAuthorize("hasRole('ASPIRANTE')")
    public ResponseEntity<Aspirante> misDatos(Authentication authentication) {
        String username = authentication.getName();
        Aspirante aspirante = aspiranteService.obtenerPorUsuario(username);
        return ResponseEntity.ok(aspirante);
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('APROBADOR','JEFE','ADMIN')")
    public ResponseEntity<List<Aspirante>> listarTodos() {
        return ResponseEntity.ok(aspiranteService.listarTodos());
    }
}
