package com.sgi.controller;

import com.sgi.dto.LoginRequest;
import com.sgi.dto.LoginResponse;
import com.sgi.dto.RegisterAspiranteRequest;
import com.sgi.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register/aspirante")
    public ResponseEntity<Void> registrarAspirante(@Valid @RequestBody RegisterAspiranteRequest request) {
        authService.registrarAspirante(request);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }
}
