package com.sgi.service;

import com.sgi.dto.CreateAspiranteRequest;
import com.sgi.model.Aspirante;
import com.sgi.repository.AspiranteRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AspiranteService {

    private final AspiranteRepository aspiranteRepository;

    public AspiranteService(AspiranteRepository aspiranteRepository) {
        this.aspiranteRepository = aspiranteRepository;
    }

    @Transactional
    public Aspirante crearAspirante(CreateAspiranteRequest request) {

        aspiranteRepository.findByDni(request.getDni())
                .ifPresent(a -> {
                    throw new IllegalArgumentException("Ya existe un aspirante con el DNI " + request.getDni());
                });

        Aspirante aspirante = new Aspirante();
        aspirante.setNombre(request.getNombre());
        aspirante.setApellido(request.getApellido());
        aspirante.setDni(request.getDni());
        aspirante.setNumeroTramiteDni(request.getNumeroTramiteDni());
        aspirante.setFechaNacimiento(request.getFechaNacimiento());
        aspirante.setEmail(request.getEmail());
        aspirante.setTelefono(request.getTelefono());
        aspirante.setEscalafon(request.getEscalafon());
        aspirante.setCargoPostulado(request.getCargoPostulado());

        return aspiranteRepository.save(aspirante);
    }

    @Transactional(readOnly = true)
    public List<Aspirante> listarTodos() {
        return aspiranteRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Aspirante obtenerPorUsuario(String username) {
        return aspiranteRepository.findByUsuarioUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("No se encontró aspirante para el usuario " + username));
    }
}
