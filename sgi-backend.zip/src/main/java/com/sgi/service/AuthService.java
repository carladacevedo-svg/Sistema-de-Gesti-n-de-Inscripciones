package com.sgi.service;

import com.sgi.dto.LoginRequest;
import com.sgi.dto.LoginResponse;
import com.sgi.dto.RegisterAspiranteRequest;
import com.sgi.model.AppUser;
import com.sgi.model.Aspirante;
import com.sgi.model.UserRole;
import com.sgi.repository.AppUserRepository;
import com.sgi.repository.AspiranteRepository;
import com.sgi.security.JwtService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

@Service
public class AuthService {

    private final AppUserRepository appUserRepository;
    private final AspiranteRepository aspiranteRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsService userDetailsService;
    private final JwtService jwtService;

    public AuthService(AppUserRepository appUserRepository,
                       AspiranteRepository aspiranteRepository,
                       PasswordEncoder passwordEncoder,
                       AuthenticationManager authenticationManager,
                       UserDetailsService userDetailsService,
                       JwtService jwtService) {
        this.appUserRepository = appUserRepository;
        this.aspiranteRepository = aspiranteRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.userDetailsService = userDetailsService;
        this.jwtService = jwtService;
    }

    @Transactional
    public void registrarAspirante(RegisterAspiranteRequest request) {

        appUserRepository.findByUsername(request.getUsername())
                .ifPresent(u -> {
                    throw new IllegalArgumentException("El usuario ya existe");
                });

        aspiranteRepository.findByDni(request.getDni())
                .ifPresent(a -> {
                    throw new IllegalArgumentException("Ya existe un aspirante con ese DNI");
                });

        AppUser user = new AppUser();
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(UserRole.ASPIRANTE);
        user.setEnabled(true);
        appUserRepository.save(user);

        Aspirante aspirante = new Aspirante();
        aspirante.setNombre(request.getNombre());
        aspirante.setApellido(request.getApellido());
        aspirante.setDni(request.getDni());
        aspirante.setNumeroTramiteDni(request.getNumeroTramiteDni());
        aspirante.setEmail(request.getEmail());
        aspirante.setTelefono(request.getTelefono());
        aspirante.setEscalafon(request.getEscalafon());
        aspirante.setCargoPostulado(request.getCargoPostulado());
        aspirante.setFechaNacimiento(LocalDate.parse(request.getFechaNacimiento()));
        aspirante.setUsuario(user);

        aspiranteRepository.save(aspirante);
    }

    public LoginResponse login(LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword()
                )
        );

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        String token = jwtService.generateToken(userDetails);

        String role = userDetails.getAuthorities().stream()
                .findFirst()
                .map(a -> a.getAuthority())
                .orElse("");

        return new LoginResponse(token, userDetails.getUsername(), role);
    }
}
