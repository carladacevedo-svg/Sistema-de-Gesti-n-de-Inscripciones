package com.sgi.service;

import com.sgi.model.Aspirante;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

@Service
public class PdfService {

    public byte[] generarPreinscripcionPdf(Aspirante aspirante) {
        try (PDDocument doc = new PDDocument()) {
            PDPage page = new PDPage(PDRectangle.A4);
            doc.addPage(page);

            try (PDPageContentStream content = new PDPageContentStream(doc, page)) {
                content.setFont(PDType1Font.HELVETICA_BOLD, 18);
                content.beginText();
                content.newLineAtOffset(50, 780);
                content.showText("Comprobante de Preinscripción - SGI");
                content.endText();

                content.setFont(PDType1Font.HELVETICA, 12);
                int y = 740;

                y = writeLine(content, "Nombre: " + aspirante.getNombre() + " " + aspirante.getApellido(), y);
                y = writeLine(content, "DNI: " + aspirante.getDni(), y);
                y = writeLine(content, "N° Trámite DNI: " + aspirante.getNumeroTramiteDni(), y);
                y = writeLine(content, "Fecha Nacimiento: " + aspirante.getFechaNacimiento(), y);
                y = writeLine(content, "E-mail: " + aspirante.getEmail(), y);
                y = writeLine(content, "Teléfono: " + aspirante.getTelefono(), y);
                y = writeLine(content, "Escalafón: " + aspirante.getEscalafon(), y);
                y = writeLine(content, "Cargo Postulado: " + aspirante.getCargoPostulado(), y);
                y = writeLine(content, "Fecha de Alta: " + aspirante.getFechaAlta(), y);
            }

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            doc.save(baos);
            return baos.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException("Error al generar el PDF de preinscripción", e);
        }
    }

    private int writeLine(PDPageContentStream content, String text, int y) throws IOException {
        content.beginText();
        content.newLineAtOffset(50, y);
        content.showText(text);
        content.endText();
        return y - 20;
    }
}
