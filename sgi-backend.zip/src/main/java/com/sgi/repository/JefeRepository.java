package com.sgi.repository;

import com.sgi.model.Jefe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JefeRepository extends JpaRepository<Jefe, Long> {
}
