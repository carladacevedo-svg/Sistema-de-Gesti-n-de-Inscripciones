package com.sgi.repository;

import com.sgi.model.Aspirante;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AspiranteRepository extends JpaRepository<Aspirante, Long> {

    Optional<Aspirante> findByDni(String dni);

    Optional<Aspirante> findByUsuarioUsername(String username);
}
