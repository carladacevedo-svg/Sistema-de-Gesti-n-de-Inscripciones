package com.sgi.repository;

import com.sgi.model.Aprobador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AprobadorRepository extends JpaRepository<Aprobador, Long> {
}
